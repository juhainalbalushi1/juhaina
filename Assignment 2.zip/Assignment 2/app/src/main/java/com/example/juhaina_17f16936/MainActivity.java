package com.example.juhaina_17f16936;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AlertDialog;
import android.view.Menu;
import android.view.MenuItem;
import android.database.Cursor;
import android.widget.Toast;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity
{

    EditText thedays, roomprice, username, phonenumber;
    TextView forresult;
    Button button1, button2, button3, button4, button5, button6, button7;
    ju2 DBase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        thedays = (EditText) findViewById(R.id.thedays);
        roomprice = (EditText) findViewById(R.id.roomprice);
        username = (EditText) findViewById(R.id.username);
        phonenumber = (EditText) findViewById(R.id.phonenumber);

        forresult = (TextView) findViewById(R.id.forresult);

        button1 = (Button) findViewById(R.id.button1);
        button2 = (Button) findViewById(R.id.button2);
        button3 = (Button) findViewById(R.id.button3);
        button4 = (Button) findViewById(R.id.button4);
        button5 = (Button) findViewById(R.id.button5);
        button6 = (Button) findViewById(R.id.button6);
        button7 = (Button) findViewById(R.id.button7);

        DBase = new ju2(this);

        calculateData();
        UData();
        DData();
        RData();
        c1Data();
        c2Data();
        insertDate();
    }

        public void calculateData() {
            button1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (thedays.getText().toString().isEmpty() || roomprice.getText().toString().isEmpty()) {
                        forresult.setText("There is No information. Please Insert the information");
                    } else {
                        int number1 = Integer.parseInt(thedays.getText().toString());
                        int number2 = Integer.parseInt(roomprice.getText().toString());
                        int multi = number1 * number2;
                        forresult.setText(String.valueOf(multi));
                    }
                }
            });
        }

        public void UData() {
            button2.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    boolean
                            update = DBase.updateData(thedays.getText().toString(), roomprice.getText().toString(), username.getText().toString()
                            , phonenumber.getText().toString());
                    if (update == true)
                        Toast.makeText(MainActivity.this, "Data is updated", Toast.LENGTH_LONG).show();
                    else
                        Toast.makeText(MainActivity.this, "Data is not updated", Toast.LENGTH_LONG).show();
                }

            });
        }

        public void DData() {
            button3.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Integer del=DBase.deleteData(thedays.getText().toString());
                    if(del>0)
                        Toast.makeText(MainActivity.this,"Data is deleted",Toast.LENGTH_LONG).show();
                    else
                        Toast.makeText(MainActivity.this,"Data is not deleted",Toast.LENGTH_LONG).show();
                }
            });
        }

        public void RData() {
            button4.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Cursor r=DBase.getAllData();
                    if(r.getCount()==0)
                    {
                        showMessage("Error", "Nothing found");
                        return;
                    }
                    StringBuffer b=new StringBuffer();
                    while(r.moveToNext())
                    {
                        b.append("The Days :"+r.getString(0)+"\n");
                        b.append("The Price of The Room :"+r.getString(1)+"\n");
                        b.append("The Username :"+r.getString(2)+"\n");
                        b.append("The Phone Number :"+r.getString(3)+"\n");
                    }
                    showMessage("The Details of the Hotel",b.toString());
                }
            });
        }

        public void c1Data() {
            button5.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (thedays.getText().toString().isEmpty() || roomprice.getText().toString().isEmpty() || username.getText().toString().isEmpty() ||
                            phonenumber.getText().toString().isEmpty()) {
                        forresult.setText("Enter Your Information Please!!");
                    } else {
                        thedays.setText("");
                        roomprice.setText("");
                        username.setText("");
                        phonenumber.setText("");
                    }
                }
            });
        }

        public void c2Data() {
            button6.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    finish();
                    System.exit(0);
                }
            });
        }

    public void insertDate()
    {
        button7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                boolean
                        insertData = DBase.insertData(thedays.getText().toString(), roomprice.getText().toString(),username.getText().toString(),
                        phonenumber.getText().toString());
                if (insertData==true)
                    Toast.makeText(MainActivity.this, "The Information are Inserted", Toast.LENGTH_LONG).show();
                else
                    Toast.makeText(MainActivity.this, "The Information are not Inserted", Toast.LENGTH_LONG).show();
            }
        });
    }

    public void showMessage(String title,String mes)
    {
        AlertDialog.Builder ad=new AlertDialog.Builder(this);
        ad.setCancelable(true);
        ad.setTitle(title);
        ad.setMessage(mes);
        ad.show();
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        getMenuInflater().inflate(R.menu.layout,menu);
        return super.onCreateOptionsMenu(menu);
    }
    public boolean onOptionsItemSelected(MenuItem menuItem)
    {
        int id=menuItem.getItemId();
        if(id==R.id.action_settings)
        {
            return true;
        }
        return super.onOptionsItemSelected(menuItem);
    }
}
